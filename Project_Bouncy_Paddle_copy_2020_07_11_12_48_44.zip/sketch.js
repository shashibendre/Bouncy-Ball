var ball,ballImg,paddle;
 var randX, randY; 
var paddleImg;

var invisiblegrounLEFT,invisiblegroundTOP,invisiblegroundBOTTOM;

function preload() {
  
  /* preload your images here of the ball and the paddle */
  paddle = loadImage("paddle.png");
  
  
}
function setup() {
  createCanvas(400, 400);
   /* create the Ball Sprite and the Paddle Sprite */
  /* assign the images to the sprites */
  
  
  /* give the ball an initial velocity of 9 in the X direction */
  paddle = createSprite(350,200,10,50);
  ball = createSprite(200,200,10,10);
 // ball.velocityX = 9;

  ball.velocityX = 2;
  
  invisiblegroundLEFT = createSprite(-8,200,10,400);
  invisiblegroundTOP = createSprite(200,-4,400,10);
  invisiblegroundBOTTOM = createSprite(200,404,400,10);
  
  }

function draw() {
  background(205,153,0);
  /* create Edge Sprites here */
  createEdgeSprites();
  invisiblegroundLEFT.visible = false;
  invisiblegroundTOP.visible = false;
  invisiblegroundBOTTOM.visible = false;
  
  ball.bounceOff(paddle);
  ball.bounceOff(invisiblegroundLEFT);
  ball.bounceOff(invisiblegroundTOP);
  ball.bounceOff(invisiblegroundBOTTOM);
  
  /* Allow the ball sprite to bounceOff the left, top and bottom edges only, leaving the right edge of the canvas to be open. */

  /* Allow the ball to bounceoff from the paddle */
  /* Also assign a collision callback function, so that the ball can have a random y velocity, making the game interesting */
 
  /* Prevent the paddle from going out of the edges */ 
  
  
  if(keyWentDown(UP_ARROW))
  {
     paddle.velocityY = -2;
  }
  
  if(keyDown(DOWN_ARROW))
  {
    paddle.velocityY = 2;
  }
  
  randomVelocity();
  drawSprites();
  
}

function randomVelocity(){

  if(ball.bounceOff(paddle)){
     randX = randomNumber(1,5);
     randY = randomNumber(1,5);
    
    if(randX == 1){
      ball.velocityX = -1
    }
     if(randY == 1){
      ball.velocityY = -1
    }
  }
  
   if(randX == 2){
      ball.velocityX = -1
    }
     if(randY == 2){
      ball.velocityY = 1
    }
  
   if(randX == 3){
      ball.velocityX = -3
    }
     if(randY == 3){
      ball.velocityX = -3
    }
  
   if(randX == 4){
      ball.velocityX = -4
    }
     if(randY == 4){
      ball.velocityX = 4
    }
  
   if(randX == 5){
      ball.velocityX = -5
    }
     if(randY == 5){
      ball.velocityX = -5
    }
  
}